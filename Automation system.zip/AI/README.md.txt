AI background:
I decided to use make.com for the task as shown in the video provided. I would’ve used a programming IDE like visual studio or android studio but I was just excited to work with something different to the traditional coding. I made use of google sheets, Perplexity AI and then a router to connect to Anthropic Claude. The scenario’s work is to post on Facebook, X(Twitter) and LinkedIn daily at 6:00 PM. 

How to run: 
It’ll be easier for user to go on make.com go to a new scenario, import my blueprint.json file then connect their social media handles, I’ll post a video to show how they can do that.
